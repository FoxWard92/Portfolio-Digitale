# Dimensione della finestra Princiale

FRAME_SIZE_X = 1280
FRAME_SIZE_Y = 720

# Tema della finestra principale

THEME_COLOR_BG = "#5f9ea0"  # Colore di sfondo chiaro
THEME_COLOR_FR = "#d9d9d9"  # Colore di sfondo chiaro per i frame
THEME_COLOR_BU = "#6495ed"  # Colore di sfondo chiaro per bottoni
THEME_COLOR_LA = "#fff8dc"  # Colore di sfondo chiaro per label

FONT_COLOR_TITLE = "#333333"  # Colore del font scuro
FONT_COLOR_BUTTON = "#333333" # Colore del font scuro per i pulsanti
FONT_COLOR_LABEL = "#333333" # Colore del font scuro per le etichette

FONT_STYLE_TITLE = ("Arial", 20,"bold")  # Stile del font
FONT_STYLE_BUTTON = ("Arial", 12,"bold")  # Stile del font per i pulsanti 
FONT_STYLE_LABEL = ("Arial", 14)  # Stile del font per le etichette

# Domande quiz Minime



MIN_QUESTIONS = 2 # Numero minimo di domande per categoria
MIN_CATEGORIES = 2 # Numero minimo di categorie