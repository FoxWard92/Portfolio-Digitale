import tkinter as tk
import scripts.pages.result as Result
import scripts.pages.quitz as Quiz
import scripts.local.cvars as cvars

class FinestraAppHome:
    def __init__(self,root):
        self.root = root

        # Imamgine di sfondo

        self.frame_bg = tk.Frame(self.root, bg=cvars.THEME_COLOR_FR)
        self.frame_bg.place(relx=0.5, rely=0.5, width=cvars.FRAME_SIZE_X - (cvars.FRAME_SIZE_X * 0.10), height=cvars.FRAME_SIZE_Y - (cvars.FRAME_SIZE_Y * 0.10), anchor="center")
        
        self.count_immagine = 0

        self.bg_image = tk.PhotoImage(file=f"img/bg/home/{self.count_immagine}.ppm")
        self.bg_frame = tk.Label(self.root, image=self.bg_image)
        self.bg_frame.place(relx=0.5, rely=0.5,width=cvars.FRAME_SIZE_X - (cvars.FRAME_SIZE_X * 0.20), height=cvars.FRAME_SIZE_Y - (cvars.FRAME_SIZE_Y * 0.20), anchor="center")
        self.on_loop_reload_immage()

        # Titolo dell'app

        self.label_title = tk.Label(self.root, text="ED CIVICA QUIZ PATENTE",font=cvars.FONT_STYLE_TITLE, fg=cvars.FONT_COLOR_TITLE ,bg=cvars.THEME_COLOR_BG)
        self.label_title.place(relx=0.5, rely=0.05,anchor="center")

        # ---------------- [Frame App] ---------------- #

        self.frame_button_quitz = tk.Frame(self.root, bg=cvars.THEME_COLOR_FR)
        self.frame_button_quitz.place(relx=0.5, rely=0.85, width=cvars.FRAME_SIZE_X - (cvars.FRAME_SIZE_X * 0.80), height=cvars.FRAME_SIZE_Y - (cvars.FRAME_SIZE_Y * 0.80), anchor="center")

        self.frame_button_results = tk.Frame(self.root, bg=cvars.THEME_COLOR_FR)
        self.frame_button_results.place(relx=0.15, rely=0.85, width=cvars.FRAME_SIZE_X - (cvars.FRAME_SIZE_X * 0.80), height=cvars.FRAME_SIZE_Y - (cvars.FRAME_SIZE_Y * 0.80), anchor="center")

        self.frame_button_exit = tk.Frame(self.root, bg=cvars.THEME_COLOR_FR)
        self.frame_button_exit.place(relx=0.85, rely=0.85, width=cvars.FRAME_SIZE_X - (cvars.FRAME_SIZE_X * 0.80), height=cvars.FRAME_SIZE_Y - (cvars.FRAME_SIZE_Y * 0.80), anchor="center")

        # Pulsanti
        self.button_resut_image = tk.PhotoImage(file="img/icons/results.ppm")
        self.button_start_image = tk.PhotoImage(file="img/icons/start.ppm")
        self.button_exit_image = tk.PhotoImage(file="img/icons/exit.ppm")
        self.button_resut = tk.Button(self.frame_button_results, font=cvars.FONT_STYLE_BUTTON,compound="top", text="Risultati", fg=cvars.FONT_COLOR_BUTTON ,bg=cvars.THEME_COLOR_BU,command=self.on_button_click_result,image=self.button_resut_image)
        self.button_start = tk.Button(self.frame_button_quitz, font=cvars.FONT_STYLE_BUTTON,compound="top", text="Quitz", fg=cvars.FONT_COLOR_BUTTON ,bg=cvars.THEME_COLOR_BU,command=self.on_button_click_start,image=self.button_start_image)
        self.button_exit = tk.Button(self.frame_button_exit, font=cvars.FONT_STYLE_BUTTON,compound="top", text="Esci", fg=cvars.FONT_COLOR_BUTTON ,bg=cvars.THEME_COLOR_BU,command=self.root.quit,image=self.button_exit_image)

        # Posizionamento pulsanti
        self.button_resut.place(relx=0.5,rely=0.5,anchor="center")
        self.button_start.place(relx=0.5,rely=0.5,anchor="center")
        self.button_exit.place(relx=0.5,rely=0.5,anchor="center")

    def on_loop_reload_immage(self):
        self.bg_image.config(file=f"img/bg/home/{self.count_immagine}.ppm")
        self.bg_frame.config(image=self.bg_image)
        self.count_immagine += 1
        if(self.count_immagine > 3):
            self.count_immagine = 0
        self.bg_image_id = self.root.after(5000,self.on_loop_reload_immage)


    def on_button_click_result(self):
        self.root.after_cancel(self.bg_image_id)
        for iframe in self.root.winfo_children():
            iframe.destroy()
        Result.FinestraAppRisultati(self.root)

    def on_button_click_start(self):
        self.root.after_cancel(self.bg_image_id)
        for iframe in self.root.winfo_children():
            iframe.destroy()
        Quiz.FinestraAppQuiz(self.root)
