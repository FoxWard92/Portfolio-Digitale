import json
import tkinter as tk
import scripts.local.cvars as cvars
import scripts.pages.home as Home

class FinestraAppRisultati:
    def __init__(self,root):
        self.root = root

        self.risultati = None

        self.numero_risultato_corrente = 0
        self.numero_domanda_corrente = 0

        try:
            with open("database/risposte.json", "r") as file:
                self.risultati = json.load(file)
        except FileNotFoundError:
            print("Il file risposte.json non è stato trovato.")
            self.on_button_click_exit()
        self.numero_risultati_totali = len(self.risultati)
        if(self.numero_risultati_totali <= 0):
            self.on_button_click_exit()
            return
        
        

        # Titolo della finestra

        self.label_title = tk.Label(self.root, text="RISULTATI QUIZ N : ", font=cvars.FONT_STYLE_TITLE, fg=cvars.FONT_COLOR_TITLE ,bg=cvars.THEME_COLOR_BG)
        self.label_title.place(relx=0.5,rely=0.1,anchor="center")

        # Frame per i risultati

        self.frame_result_dettails = tk.Frame(self.root, bg=cvars.THEME_COLOR_FR)
        self.frame_result_dettails.place(relx=0.5, rely=0.5,width=cvars.FRAME_SIZE_X - (cvars.FRAME_SIZE_X * 0.10), height=cvars.FRAME_SIZE_Y - (cvars.FRAME_SIZE_Y * 0.70), anchor="center")

        self.label_result_categoria = tk.Label(self.frame_result_dettails, font=cvars.FONT_STYLE_LABEL, fg=cvars.FONT_COLOR_LABEL ,bg=cvars.THEME_COLOR_LA)
        self.label_result_categoria.place(relx=0.2,rely=0.15,anchor="center")

        self.label_result_blocco = tk.Label(self.frame_result_dettails, font=cvars.FONT_STYLE_LABEL, fg=cvars.FONT_COLOR_LABEL ,bg=cvars.THEME_COLOR_LA)
        self.label_result_blocco.place(relx=0.85,rely=0.15,anchor="center")

        self.label_result_domanda = tk.Label(self.frame_result_dettails, font=cvars.FONT_STYLE_LABEL, fg=cvars.FONT_COLOR_LABEL ,bg=cvars.THEME_COLOR_LA,wraplength=700)
        self.label_result_domanda.place(relx=0.4,rely=0.5,anchor="center")

        self.label_result_risposta = tk.Label(self.frame_result_dettails, font=cvars.FONT_STYLE_LABEL, fg=cvars.FONT_COLOR_LABEL ,bg=cvars.THEME_COLOR_LA)
        self.label_result_risposta.place(relx=0.85,rely=0.5,anchor="center")

        self.frame_result_info = tk.Frame(self.root, bg=cvars.THEME_COLOR_FR)
        self.frame_result_info.place(relx=0.7, rely=0.2,width=cvars.FRAME_SIZE_X - (cvars.FRAME_SIZE_X * 0.50), height=cvars.FRAME_SIZE_Y - (cvars.FRAME_SIZE_Y * 0.90), anchor="center")

        self.label_result_punteggio = tk.Label(self.frame_result_info, font=cvars.FONT_STYLE_LABEL, fg=cvars.FONT_COLOR_LABEL ,bg=cvars.THEME_COLOR_LA)
        self.label_result_punteggio.place(relx=0.8,rely=0.5,anchor="center")

        self.label_result_numero_domande = tk.Label(self.frame_result_info, font=cvars.FONT_STYLE_LABEL, fg=cvars.FONT_COLOR_LABEL ,bg=cvars.THEME_COLOR_LA)
        self.label_result_numero_domande.place(relx=0.3,rely=0.5,anchor="center")


        # Immagine di sfondo pulsanti

        self.button_next_risultato_image = tk.PhotoImage(file="img/icons/next.ppm")
        self.button_bin_image = tk.PhotoImage(file="img/icons/bin.ppm")
        self.button_preview_risultato_image = tk.PhotoImage(file="img/icons/preview.ppm")
        self.button_annulla_image = tk.PhotoImage(file="img/icons/exit.ppm")
        
        self.frame_button_result = tk.Frame(self.root, bg=cvars.THEME_COLOR_FR)
        self.frame_button_result.place(relx=0.5, rely=0.85,width=cvars.FRAME_SIZE_X - (cvars.FRAME_SIZE_X * 0.10), height=cvars.FRAME_SIZE_Y - (cvars.FRAME_SIZE_Y * 0.80), anchor="center")

        self.frame_button_azione = tk.Frame(self.root, bg=cvars.THEME_COLOR_FR)
        self.frame_button_azione.place(relx=0.2, rely=0.2,width=cvars.FRAME_SIZE_X - (cvars.FRAME_SIZE_X * 0.70), height=cvars.FRAME_SIZE_Y - (cvars.FRAME_SIZE_Y * 0.90), anchor="center")

        self.label_numero_risultato_corrente = tk.Label(self.frame_button_result, font=cvars.FONT_STYLE_LABEL, fg=cvars.FONT_COLOR_LABEL ,bg=cvars.THEME_COLOR_LA)
        self.label_numero_risultato_corrente.place(relx=0.5,rely=0.5,anchor="center")

        # Pulsanti
        
        

        self.button_next_risultato = tk.Button(self.frame_button_result, text="AVANTI", compound="top", font=cvars.FONT_STYLE_BUTTON, fg=cvars.FONT_COLOR_BUTTON, bg=cvars.THEME_COLOR_BU,command=self.on_button_click_avanti_risultato ,image=self.button_next_risultato_image,state=tk.DISABLED if self.numero_risultati_totali <= 1 else tk.NORMAL)
        self.button_preview_risultato = tk.Button(self.frame_button_result, text="INDIETRO", compound="top", font=cvars.FONT_STYLE_BUTTON, fg=cvars.FONT_COLOR_BUTTON, bg=cvars.THEME_COLOR_BU,command=self.on_button_click_indietro_risultato ,image=self.button_preview_risultato_image,state=tk.DISABLED)
        self.button_next_domanda = tk.Button(self.frame_button_result, text="DOMANDA SUCESSUVA", compound="top", font=cvars.FONT_STYLE_BUTTON, fg=cvars.FONT_COLOR_BUTTON, bg=cvars.THEME_COLOR_BU,command=self.on_button_click_avanti_domanda ,image=self.button_next_risultato_image)
        self.button_preview_domanda = tk.Button(self.frame_button_result, text="DOMANDA PRECEDENTE", compound="top", font=cvars.FONT_STYLE_BUTTON, fg=cvars.FONT_COLOR_BUTTON, bg=cvars.THEME_COLOR_BU,command=self.on_button_click_indietro_domanda ,image=self.button_preview_risultato_image,state=tk.DISABLED)
        self.button_annulla = tk.Button(self.frame_button_azione, text="ESCI ", compound="left", font=cvars.FONT_STYLE_BUTTON, fg=cvars.FONT_COLOR_BUTTON, bg=cvars.THEME_COLOR_BU,command=self.on_button_click_exit ,image=self.button_annulla_image)
        self.button_remove = tk.Button(self.frame_button_azione, text="RIMUOVI", compound="left", font=cvars.FONT_STYLE_BUTTON, fg=cvars.FONT_COLOR_BUTTON, bg=cvars.THEME_COLOR_BU,command=self.on_button_click_remove_result ,image=self.button_bin_image)

        # Posizionamento pulsanti
        
        self.button_next_risultato.place(relx=0.9,rely=0.5,anchor="center")
        self.button_preview_risultato.place(relx=0.1,rely=0.5,anchor="center")
        self.button_next_domanda.place(relx=0.7,rely=0.5,anchor="center")
        self.button_preview_domanda.place(relx=0.3,rely=0.5,anchor="center")
        self.button_annulla.place(relx=0.8,rely=0.5,anchor="center")
        self.button_remove.place(relx=0.2,rely=0.5,anchor="center")

        # Label Risultati
        #
        self.on_reload_risposte()
        

    def on_button_click_avanti_risultato(self):
        self.numero_risultato_corrente += 1
        self.numero_domanda_corrente = 0
        if(self.numero_risultato_corrente >= self.numero_risultati_totali-1):
            self.button_next_risultato.config(state=tk.DISABLED)
        self.button_preview_risultato.config(state=tk.NORMAL)
        self.button_preview_domanda.config(state=tk.DISABLED)
        self.button_next_domanda.config(state=tk.NORMAL)
        self.on_reload_risposte()

    def on_button_click_indietro_risultato(self):
        self.numero_risultato_corrente -= 1
        self.numero_domanda_corrente = 0
        if(self.numero_risultato_corrente <= 0):
            self.button_preview_risultato.config(state=tk.DISABLED)
        self.button_next_risultato.config(state=tk.NORMAL)
        self.button_preview_domanda.config(state=tk.DISABLED)
        self.button_next_domanda.config(state=tk.NORMAL)
        self.on_reload_risposte()
    
    def on_button_click_avanti_domanda(self):
        self.numero_domanda_corrente += 1
        self.on_reload_risposte()

    def on_button_click_indietro_domanda(self):
        self.numero_domanda_corrente -= 1
        self.on_reload_risposte()

    def on_button_click_exit(self):
        for iframe in self.root.winfo_children():
            iframe.destroy()
        Home.FinestraAppHome(self.root)

    def on_reload_risposte(self):



        RC = self.risultati[self.numero_risultato_corrente]
        self.numero_domande_totali = len(self.risultati[self.numero_risultato_corrente]["domande"])
        self.label_title.config(text=f"RISULTATI QUIZ IN DATA : {RC["data"]}")
        self.label_result_blocco.config(text=f"Blocco : {RC["domande"][self.numero_domanda_corrente]["blocco"]}")
        self.label_result_categoria.config(text=f"Categoria : {RC["domande"][self.numero_domanda_corrente]["categoria"]}")
        self.label_result_punteggio.config(text=f"Punteggio : {RC["punteggio"]:02f}%")
        self.label_result_numero_domande.config(text=f"Numero Di Categorie : {RC["nc"]}\n Numero Di Domande Per Categoria : {RC["nd"]}")
        self.label_result_domanda.config(text=f"{RC["domande"][self.numero_domanda_corrente]["testo"]}")
        self.label_result_risposta.config(text=f"Risposta Data : {RC["domande"][self.numero_domanda_corrente]["risposta"]}\nCorretta : {RC["domande"][self.numero_domanda_corrente]["risposta_corretta"]}")
        self.label_numero_risultato_corrente.config(text=f"QUITZ : {self.numero_risultato_corrente+1} / {self.numero_risultati_totali}\n DOMANDA : {self.numero_domanda_corrente+1} / {self.numero_domande_totali}")
        
        self.button_next_domanda.config(state=tk.DISABLED if self.numero_domanda_corrente >= self.numero_domande_totali-1 else tk.NORMAL)
        self.button_preview_domanda.config(state=tk.DISABLED if self.numero_domanda_corrente <= 0  else tk.NORMAL)
    
    def on_button_click_remove_result(self):
        self.risultati.pop(self.numero_risultato_corrente)
        try:
            with open("database/risposte.json", "w") as file:
                json.dump(self.risultati, file, ensure_ascii=False, indent=4)

            self.numero_risultati_totali = len(self.risultati)
            if(self.numero_risultato_corrente > 0):
               self.numero_risultato_corrente = self.numero_risultato_corrente - 1
            
            if(self.numero_risultati_totali <= 0):
                self.on_button_click_exit()
            else:
                self.on_reload_risposte()
        except Exception as e:
            print(f"Errore File Rispsote : {e}")
            self.on_button_click_exit()
