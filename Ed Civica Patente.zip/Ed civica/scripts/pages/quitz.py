import tkinter as tk
from tkinter import messagebox
import scripts.local.cvars as cvars
import scripts.pages.home as Home
import json
from random import sample as rd
from datetime import datetime

class FinestraAppQuiz:
    def __init__(self,root):
        self.root = root
        self.timer_after_id = None

        # Caricamento del file JSON delle domande

        try:
            with open("database/domande.json", "r") as file:
                self.categorie = json.load(file)
        except FileNotFoundError:
            print("Il file domande.json non è stato trovato.")
            self.on_button_click_exit()

        # Mescoliaomo le domande se maggiori del minimo richiesto

        self.domande = []

        if len(self.categorie) >= cvars.MIN_CATEGORIES:
            for x in range(cvars.MIN_CATEGORIES):
                categoria = self.categorie[x] 
                if len(categoria["domande"]) >= cvars.MIN_QUESTIONS:
                    selezioni = rd(categoria["domande"], cvars.MIN_QUESTIONS)
                    for selezione in selezioni:
                        self.domande.append({"categoria":categoria["categoria"],"blocco":categoria["blocco"],"testo":selezione["testo"],"risposta":None,"risposta_corretta":selezione["risposta"]})
                        if("immagine" in selezione):
                            self.domande[-1]["immagine"] = selezione["immagine"]
                else:
                    print(f"Il numero di domande nella categoria : {categoria["categoria"]} è inferiore al numero minimo richiesto.")
                    self.on_button_click_exit()
                    return
        else:
            print("Il numero di categorie nel file JSON è inferiore al numero minimo richiesto.")
            self.on_button_click_exit()

        # Inizializzazione della variabile per il numero di domande correnti

        self.numero_domanda_corrente = 0

        self.numero_domanda_totali = len(self.domande)

        self.domanda_corrente = self.domande[self.numero_domanda_corrente]

        #--------------[Title]--------------#

        self.label_titlle = tk.Label(self.root, text=f"QUITZ TEST B", font=cvars.FONT_STYLE_TITLE, fg=cvars.FONT_COLOR_TITLE ,bg=cvars.THEME_COLOR_BG)
        self.label_titlle.place(relx=0.7,rely=0.1,anchor="center")

        #--------------[Timer]--------------#

        # Frame

        self.frame_timer = tk.Frame(self.root, bg=cvars.THEME_COLOR_FR)
        self.frame_timer.place(relx=0.2, rely=0.9,width=cvars.FRAME_SIZE_X - (cvars.FRAME_SIZE_X*0.70),height=cvars.FRAME_SIZE_Y - (cvars.FRAME_SIZE_Y*0.90), anchor="center")

        # Label

        self.timer = [30,0]

        self.label_timer = tk.Label(self.frame_timer, text=f"{self.timer[0]:02d}:{self.timer[1]:02d}", font=cvars.FONT_STYLE_LABEL, fg=cvars.FONT_COLOR_LABEL ,bg=cvars.THEME_COLOR_LA)
        self.label_timer.place(relx=0.5,rely=0.5,anchor="center")
        
        self.timer_after_id = self.root.after(1000,self.timer_loop)

        #--------------[Immmagine Domanda]--------------#

        # Frame

        self.frame_imamgine_domanda = tk.Frame(self.root, bg=cvars.THEME_COLOR_FR)
        self.frame_imamgine_domanda.place(relx=0.2, rely=0.5,width=cvars.FRAME_SIZE_X - (cvars.FRAME_SIZE_X*0.70),height=cvars.FRAME_SIZE_Y - (cvars.FRAME_SIZE_Y*0.35), anchor="center")

        # Label
            
        self.label_sing = tk.Label(self.frame_imamgine_domanda, bg=cvars.THEME_COLOR_FR)
        self.label_sing.place(relx=0.5,rely=0.5,anchor="center")

        #--------------[Domanda info]--------------#

        # Frame

        self.frame_domanda = tk.Frame(self.root, bg=cvars.THEME_COLOR_FR)
        self.frame_domanda.place(relx=0.68, rely=0.325,width=cvars.FRAME_SIZE_X - (cvars.FRAME_SIZE_X*0.40),height=cvars.FRAME_SIZE_Y - (cvars.FRAME_SIZE_Y*0.70), anchor="center")

        # Label

        self.label_categoria = tk.Label(self.frame_domanda, font=cvars.FONT_STYLE_LABEL, fg=cvars.FONT_COLOR_LABEL ,bg=cvars.THEME_COLOR_LA)
        self.label_categoria.place(relx=0.2,rely=0.15,anchor="center")

        self.label_blocco = tk.Label(self.frame_domanda, font=cvars.FONT_STYLE_LABEL, fg=cvars.FONT_COLOR_LABEL ,bg=cvars.THEME_COLOR_LA)
        self.label_blocco.place(relx=0.9,rely=0.15,anchor="center")

        self.label_domanda = tk.Label(self.frame_domanda, font=cvars.FONT_STYLE_LABEL, fg=cvars.FONT_COLOR_LABEL ,bg=cvars.THEME_COLOR_LA,wraplength=700)
        self.label_domanda.place(relx=0.5,rely=0.55,anchor="center")
        
        # Frame Barra Di Scorrimento 

        self.frame_barra_di_scorrimento = tk.Frame(self.root, bg=cvars.THEME_COLOR_FR)
        self.frame_barra_di_scorrimento.place(relx=0.68, rely=0.85,width=cvars.FRAME_SIZE_X - (cvars.FRAME_SIZE_X*0.40),height=cvars.FRAME_SIZE_Y - (cvars.FRAME_SIZE_Y*0.80), anchor="center")

        self.barra_di_scorrimento_lista = []

        self.on_barra_di_scorrimeto_reload()

        # Frame Pulsanti Risposta

        self.frame_pulsanti_risposta = tk.Frame(self.root,bg=cvars.THEME_COLOR_FR)
        self.frame_pulsanti_risposta.place(relx=0.68, rely=0.6,width=cvars.FRAME_SIZE_X - (cvars.FRAME_SIZE_X*0.40),height=cvars.FRAME_SIZE_Y - (cvars.FRAME_SIZE_Y*0.80), anchor="center")

        self.label_domanda_coorente = tk.Label(self.frame_pulsanti_risposta, font=cvars.FONT_STYLE_LABEL, fg=cvars.FONT_COLOR_LABEL ,bg=cvars.THEME_COLOR_LA)
        self.label_domanda_coorente.place(relx=0.5,rely=0.5,anchor="center")
        
        # Frame Pulsanti Azione
        self.frame_pulsanti_azione = tk.Frame(self.root,bg=cvars.THEME_COLOR_FR)
        self.frame_pulsanti_azione.place(relx=0.2, rely=0.1,width=cvars.FRAME_SIZE_X - (cvars.FRAME_SIZE_X*0.70),height=cvars.FRAME_SIZE_Y - (cvars.FRAME_SIZE_Y*0.90), anchor="center")
        
        # Immagine di sfondo pulsanti

        self.button_true_image = tk.PhotoImage(file="img/icons/true.ppm")
        self.button_false_image = tk.PhotoImage(file="img/icons/false.ppm")
        self.button_next_image = tk.PhotoImage(file="img/icons/next.ppm")
        self.button_preview_image = tk.PhotoImage(file="img/icons/preview.ppm")
        self.button_annulla_image = tk.PhotoImage(file="img/icons/exit.ppm")
        self.button_correggi_image = tk.PhotoImage(file="img/icons/correct.ppm")

        # Pulsanti

        self.button_true = tk.Button(self.frame_pulsanti_risposta, text="Vero", compound="top", font=cvars.FONT_STYLE_BUTTON, fg=cvars.FONT_COLOR_BUTTON, bg=cvars.THEME_COLOR_BU, command=self.on_button_click_true ,image=self.button_true_image)
        self.button_false = tk.Button(self.frame_pulsanti_risposta, text="Falso", compound="top", font=cvars.FONT_STYLE_BUTTON, fg=cvars.FONT_COLOR_BUTTON, bg=cvars.THEME_COLOR_BU,command=self.on_button_click_false ,image=self.button_false_image)
        self.button_next = tk.Button(self.frame_pulsanti_risposta, text="Avanti", compound="top", font=cvars.FONT_STYLE_BUTTON, fg=cvars.FONT_COLOR_BUTTON, bg=cvars.THEME_COLOR_BU,command=self.on_button_click_avanti ,image=self.button_next_image)
        self.button_preview = tk.Button(self.frame_pulsanti_risposta, text="Indietro", compound="top", font=cvars.FONT_STYLE_BUTTON, fg=cvars.FONT_COLOR_BUTTON, bg=cvars.THEME_COLOR_BU,command=self.on_button_click_indietro ,image=self.button_preview_image,state=tk.DISABLED)
        self.button_annulla = tk.Button(self.frame_pulsanti_azione, text="ESCI ", compound="left", font=cvars.FONT_STYLE_BUTTON, fg=cvars.FONT_COLOR_BUTTON, bg=cvars.THEME_COLOR_BU,command=self.on_button_click_exit ,image=self.button_annulla_image)
        self.button_correggi = tk.Button(self.frame_pulsanti_azione, text="Correggi ", compound="left", font=cvars.FONT_STYLE_BUTTON, fg=cvars.FONT_COLOR_BUTTON, bg=cvars.THEME_COLOR_BU,command=self.on_button_click_correggi ,image=self.button_correggi_image)

        # Posizionamento pulsanti

        self.button_true.place(relx=0.1,rely=0.5,anchor="center")
        self.button_false.place(relx=0.3,rely=0.5,anchor="center")
        self.button_next.place(relx=0.9,rely=0.5,anchor="center")
        self.button_preview.place(relx=0.7,rely=0.5,anchor="center")
        self.button_annulla.place(relx=0.85,rely=0.5,anchor="center")
        self.button_correggi.place(relx=0.2,rely=0.5,anchor="center")

        self.reload_domande()

    def on_button_click_true(self):
        self.domanda_corrente["risposta"] = True
        self.button_true.config(state=tk.DISABLED)
        self.button_false.config(state=tk.NORMAL)
        self.barra_di_scorrimento_lista[self.numero_domanda_corrente].config(bg="#047500")

    def on_button_click_false(self):
        self.domanda_corrente["risposta"] = False
        self.button_false.config(state=tk.DISABLED)
        self.button_true.config(state=tk.NORMAL)
        self.barra_di_scorrimento_lista[self.numero_domanda_corrente].config(bg="#5c0006")

    def on_button_click_indietro(self):
        self.numero_domanda_corrente -= 1
        self.reload_domande()

    def on_button_click_avanti(self):
        self.numero_domanda_corrente += 1
        self.reload_domande()
    
    def on_button_click_exit(self):
        if(self.timer_after_id is not None):
            self.root.after_cancel(self.timer_after_id)

        for iframe in self.root.winfo_children():
            iframe.destroy()
        Home.FinestraAppHome(self.root)

    def on_button_click_correggi(self):
        try:
            risultati_test = {"data":datetime.now().strftime("%Y-%m-%d %H:%M:%S"),"punteggio":0,"nd":cvars.MIN_QUESTIONS,"nc":cvars.MIN_CATEGORIES,"domande":[]}
            punteggio = 0
            for x in self.domande:
                if(x["risposta"] != None):
                    if(x["risposta"] == x["risposta_corretta"]):
                        punteggio = punteggio + 1
                    risultati_test["domande"].append(x)
                else:
                   messagebox.showinfo("Attenzione!!", f"Non Completato Il Test mancante domanda: {len(risultati_test['domande']) + 1}" if len(risultati_test['domande']) >= 2 else "Non Completato Il Test mancanti domande")
                   return
            risultati_test["punteggio"] = punteggio/len(self.domande)*100
            
            risposte_file = None

            with open("database/risposte.json", "r") as file:
                risposte_file = json.load(file)

            with open("database/risposte.json", "w") as file:
                risposte_file.append(risultati_test)
                json.dump(risposte_file, file, ensure_ascii=False, indent=4)
                messagebox.showinfo("Test Corretto!!", f"Il Quiz {'è superato' if risultati_test['punteggio'] >= 70 else 'non è superato'}: {risultati_test['punteggio']}%")
                self.on_button_click_exit()

        except Exception as e:
            print(f"Errore Salvataggio Risultati : {e}")
        

    def reload_domande(self):
        
        self.domanda_corrente = self.domande[self.numero_domanda_corrente]

        self.button_false.config(state=tk.NORMAL)
        self.button_true.config(state=tk.NORMAL)

        
        if self.domanda_corrente["risposta"] == True:
            self.button_true.config(state=tk.DISABLED)
        elif self.domanda_corrente["risposta"] == False:
            self.button_false.config(state=tk.DISABLED)

        self.button_next.config(state=tk.DISABLED if self.numero_domanda_corrente >= self.numero_domanda_totali - 1 else tk.NORMAL)
        self.button_preview.config(state=tk.DISABLED if self.numero_domanda_corrente <= 0 else tk.NORMAL)

        self.label_domanda_coorente.config(text=f"{self.numero_domanda_corrente+1}/{self.numero_domanda_totali}")

        self.label_categoria.config(text=f"Categoria : {self.domanda_corrente["categoria"]}")

        self.label_blocco.config(text=f"Blocco : {self.domanda_corrente["blocco"]}")

        self.label_domanda.config(text=f"{self.domanda_corrente["testo"]}?")

        if("immagine" in self.domanda_corrente):
            try:
               self.sing_image = tk.PhotoImage(file=f"{self.domanda_corrente["immagine"]}")
               self.label_sing.config(image=self.sing_image)
            except Exception as e:
               print(f"Errore nel caricamento dell'immagine '{self.domanda_corrente["immagine"]}': {e}")
        else:
            self.label_sing.config(image="")
    
    def timer_loop(self):
        total_seconds = self.timer[0] * 60 + self.timer[1] - 1

        if total_seconds < 0:
           self.on_button_click_correggi()
           return

        self.timer = [total_seconds // 60, total_seconds % 60]
        self.label_timer.config(text=f"{self.timer[0]:02d}:{self.timer[1]:02d}")
 
        self.timer_after_id = self.root.after(1000, self.timer_loop)

    def on_barra_di_scorrimeto_reload(self):
        NUM_MAX_FOR_ROW = 20
        C = cvars.MIN_QUESTIONS * cvars.MIN_CATEGORIES

        for x in range(C):
            self.barra_di_scorrimento_lista.append(tk.Button(self.frame_barra_di_scorrimento, text=f"{x+1:02d}", compound="top", font=cvars.FONT_STYLE_BUTTON, fg=cvars.FONT_COLOR_BUTTON, bg=cvars.THEME_COLOR_BU, command=lambda x=x: (setattr(self, "numero_domanda_corrente", x) or self.reload_domande())))
            self.barra_di_scorrimento_lista[-1].place(relx=(x % NUM_MAX_FOR_ROW + 1.5) / (NUM_MAX_FOR_ROW + 2),rely=int(x/NUM_MAX_FOR_ROW)*0.3 + 0.2,anchor="center")
