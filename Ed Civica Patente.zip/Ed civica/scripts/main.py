import tkinter as tk
from scripts.local import cvars
from scripts.pages import home as pages

def main():
    root = tk.Tk()
    root.title("ED CIVICA QUIZ PATENTE")
    root.geometry(f"{cvars.FRAME_SIZE_X}x{cvars.FRAME_SIZE_Y}")
    root.resizable(False, False)
    root.configure(bg=cvars.THEME_COLOR_BG)  # Sfondo chiaro
    pages.FinestraAppHome(root)
    root.mainloop()

main()

#avviare il code da /python -m scripts.main